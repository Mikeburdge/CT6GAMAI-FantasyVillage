﻿using Assets.Scripts.Villagers;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreeScript : MonoBehaviour
{

    public float Health = 100;

    public int WoodPerChop = 10;

    [SerializeField]
    private float DamageRecievedMultiplier = 4;

    public void Chop(Villager villager)
    {
        float damageToTree = villager.GatheringSpeed * DamageRecievedMultiplier;

        Health -= damageToTree;

    }


}
