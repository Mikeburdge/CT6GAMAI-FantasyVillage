﻿using Assets.Scripts.FiniteStateMachine.States;
using Assets.Scripts.Villagers;
using LocationThings;
using UnityEngine;

namespace Assets.Scripts.UtilityTheory.Desires
{
    public class ReturnHomeDesire : Desire
    {
        public ReturnHomeDesire()
        {
            state = GoHomeAndSleep.Instance;
        }

        public override void CalculateDesireValue(Villager villager)
        {

            float bias = villager.ReturnHomeBias;

            float factorOne = 1 - (villager.Health / 100);


            float distance = Vector3.Distance(villager.transform.position, LocationPositions.GetPositionFromLocation(LocationNames.home));

            desireVal = bias * (factorOne / distance * 100);

            return;
        }
    }
}