﻿using Assets.Scripts.FiniteStateMachine.States;
using Assets.Scripts.Villagers;
using UnityEngine;
using LocationThings;
using Storage;

namespace Assets.Scripts.UtilityTheory.Desires
{
    public class StartGatheringDesire : Desire
    {
        public StartGatheringDesire()
        {
            state = StartGathering.Instance;
        }

        public override void CalculateDesireValue(Villager villager)
        {
            
            float bias = villager.StartGatheringBias;

            float factorOne = 1 - (StorageContainer.WoodInStorage / 100);

            Vector3 forestPosition = LocationPositions.GetPositionFromLocation(LocationNames.forest);

            float distance = Vector3.Distance(villager.transform.position, forestPosition);

            desireVal = bias * (factorOne / distance * 100);

            return;
        }
    }
}