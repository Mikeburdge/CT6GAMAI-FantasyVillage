﻿namespace Assets.Scripts
{
    public enum Professions
    {
    Warrior,
    Archer,
    Farmer,
    Worker,
    Child,
    Wizard
    }
}