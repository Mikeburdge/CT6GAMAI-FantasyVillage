﻿using UnityEngine;
using System.Collections;
using Assets.Scripts.FiniteStateMachine.States;

namespace Assets.Scripts.FiniteStateMachine
{
    public class EventHandler
    {
        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
        }
    }
}