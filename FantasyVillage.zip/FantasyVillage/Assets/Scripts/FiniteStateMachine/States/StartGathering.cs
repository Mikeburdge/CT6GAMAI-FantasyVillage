﻿using Assets.Scripts.Villagers;
using LocationThings;
using UnityEngine;

namespace Assets.Scripts.FiniteStateMachine.States
{

    public sealed class StartGathering : State<Villager>
    {
        public static StartGathering Instance { get; } = new StartGathering();
        static StartGathering() { }
        private StartGathering() { }


        public override void Enter(Villager v)
        {
                Debug.Log(v.name + " is Entering the forest...");
        }

        public override void Execute(Villager v)
        {
            Debug.Log(v.name + " chopped wood for a bit");
            v.ExecuteBT();
        }

        public override void Exit(Villager v)
        {
            Debug.Log(v.name + " is leaving the forest");
        }
    }
}