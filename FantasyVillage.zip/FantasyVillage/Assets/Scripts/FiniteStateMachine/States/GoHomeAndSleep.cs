﻿using Assets.Scripts.Villagers;
using LocationThings;
using UnityEngine;

namespace Assets.Scripts.FiniteStateMachine.States
{

    public sealed class GoHomeAndSleep : State<Villager>
    {
        public static GoHomeAndSleep Instance { get; } = new GoHomeAndSleep();
        static GoHomeAndSleep() { }
        private GoHomeAndSleep() { }


        public override void Enter(Villager v)
        {
                Debug.Log(v.name + "Is Entering their home...");
        }

        public override void Execute(Villager v)
        {
            Debug.Log(v.name + " slept at home");

        }

        public override void Exit(Villager v)
        {
            Debug.Log(v.name + " has left their house");
        }
    }
}