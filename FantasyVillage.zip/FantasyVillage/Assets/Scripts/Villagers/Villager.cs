﻿using Assets.BehaviourTrees;
using Assets.BehaviourTrees.VillagerBlackboards;
using Assets.Scripts.FiniteStateMachine;
using Assets.Scripts.FiniteStateMachine.States;
using Assets.Scripts.UtilityTheory;
using Assets.Scripts.UtilityTheory.Desires;
using LocationThings;
using Priority_Queue;
using Storage;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;

namespace Assets.Scripts.Villagers
{
    [RequireComponent(typeof(VillagerBB))]
    public class Villager : MonoBehaviour
    {
        private StateMachine<Villager> FSM;

        private SimplePriorityQueue<Desire> priorityQueue = new SimplePriorityQueue<Desire>();

        public Desire ReturnHomeDesire;
        public Desire BeginGatheringDesire;


        public Villager(StateMachine<Villager> fSM)
        {
            FSM = fSM;
        }

        #region Variables


        //Health is out of 100
        private int health;

        protected int Damage;

        public float MoveSpeed;

        protected float AttackCooldown;

        //Combat Skill: Determines the this villagers Capabilities in Combat
        protected int CombatSpeed;

        //Construction Skill: Determines the speed in which this villager can construct or repair buildings
        protected int ConstructionSpeed;

        //Farming Skill: Determines speed in which this villager can farm food
        protected int FarmingSpeed;

        //Gathering Skill: Determines the speed in which this villager gathers wood and rocks from trees and bigger rocks
        private int gatheringSpeed;

        protected bool isFemale;

        public NavMeshAgent navMesh;

        private float returnHomeBias;

        private float startGatheringBias;


        /// 
        /// Getters and Setters
        /// 
        public float ReturnHomeBias { get => returnHomeBias; set => returnHomeBias = value; }
        public float StartGatheringBias { get => startGatheringBias; set => startGatheringBias = value; }
        public int Health { get => health; set => health = value; }
        public int GatheringSpeed { get => gatheringSpeed; set => gatheringSpeed = value; }


        //Behaviour Trees
        public BTNode BTRootNode;


        #endregion



        public void Awake()
        {
            InitVariables();
            navMesh = GetComponent<NavMeshAgent>();
            FSM = new StateMachine<Villager>();
            FSM.Configure(this, DefaultState.Instance);

            priorityQueue = new SimplePriorityQueue<Desire>();
            ReturnHomeDesire = new ReturnHomeDesire();
            BeginGatheringDesire = new StartGatheringDesire();
            priorityQueue.Enqueue(BeginGatheringDesire, 1.0f);
            priorityQueue.Enqueue(ReturnHomeDesire, 2.0f);

            InvokeRepeating(nameof(UpdateStateChange), 0.1f, 0.1f);
        }

        protected virtual void InitVariables() { }

        public void ChangeState(State<Villager> S)
        {
            FSM.ChangeState(S);
        }


        void UpdateStateChange()
        {
            Debug.Log("This Should Update Every 0.1 Seconds");

            foreach (Desire desire in priorityQueue)
            {
                desire.CalculateDesireValue(this);
                priorityQueue.UpdatePriority(desire, desire.desireVal);
            }

            State<Villager> potentialState = priorityQueue.Last().state;

            if (!FSM.CheckCurrentState(potentialState))
            {
                ChangeState(potentialState);
            }


        }

        private void Start()
        {

            //Get reference to Villager Blackboard
            VillagerBB bb = GetComponent<VillagerBB>();
            //Create our root selector
            //Selector rootChild = new Selector(bb); // selectors will execute it's children 1 by 1 until one of them succeeds


            //Chop Trees Sequence
            CompositeNode ChopTreeSequence = new Sequence(bb); // The sequence of actions to take when chopping trees

            BTRootNode = ChopTreeSequence;

            ChopTreeSequence.AddChild(new GetMoveToLocation(bb, LocationNames.forest)); // gets the location to move towards
            ChopTreeSequence.AddChild(new VillagerMoveTo(bb, this)); // move to the calculated destination
            ChopTreeSequence.AddChild(new VillagerWaitTillAtLocation(bb, this)); // wait till we reached destination
            ChopTreeSequence.AddChild(new PickNearestTree(bb, this)); // pick the nearest tree to chop
            ChopTreeSequence.AddChild(new VillagerMoveTo(bb, this)); // move to the calculated destination
            ChopTreeSequence.AddChild(new VillagerWaitTillAtLocation(bb, this)); // wait till we reached destination
            ChopTreeSequence.AddChild(new VillagerStopMovement(bb, this)); // stop movement
            ChopTreeSequence.AddChild(new DelayNode(bb, 2.0f)); // wait for 2 seconds
                       

            ////Adding to root selector
            //rootChild.AddChild(ChopTreeSequence);

            ////Execute our BT every 0.1 seconds
            InvokeRepeating(nameof(UpdateFSM), 0.1f, 0.1f);
        }


        public void VillagerMoveTo(Vector3 MoveLocation)
        {
            navMesh.SetDestination(MoveLocation);
        }

        public void StopMovement()
        {
            navMesh.isStopped = true;
        }

        public void UpdateFSM()
        {
            FSM.Update();
        }

        public void ExecuteBT()
        {
            BTRootNode.Execute();
        }
    }

    public class GetMoveToLocation : BTNode
    {
        private VillagerBB vBB;

        private LocationNames targetLocation;


        public GetMoveToLocation(BaseBlackboard bb, LocationNames inLocations) : base(bb)
        {
            vBB = (VillagerBB)bb;
            targetLocation = inLocations;
        }

        public override BTStatus Execute()
        {
            Vector3 TargetPosition = LocationPositions.GetPositionFromLocation(targetLocation);

            if (TargetPosition == Vector3.zero)
            {
                Debug.Log(this + " target position is " + Vector3.zero);
                return BTStatus.FAILURE;
            }

            Debug.Log(this + " target position is " + TargetPosition);

            vBB.MoveToLocation = TargetPosition;


            return BTStatus.SUCCESS;
        }
    }

    public class VillagerMoveTo : BTNode
    {
        private VillagerBB vBB;
        private Villager villagerRef;

        public VillagerMoveTo(BaseBlackboard bb, Villager villager) : base(bb)
        {
            vBB = (VillagerBB)bb;
            villagerRef = villager;
        }

        public override BTStatus Execute()
        {
            Debug.Log("Moving to location");
            villagerRef.VillagerMoveTo(vBB.MoveToLocation);
            return BTStatus.SUCCESS;
        }
    }

    public class PickNearestTree : BTNode
    {
        private VillagerBB vBB;
        private Villager villagerRef;

        public PickNearestTree(BaseBlackboard bb, Villager villager) : base(bb)
        {
            vBB = (VillagerBB)bb;
            villagerRef = villager;
        }

        public override BTStatus Execute()
        {
            Debug.Log("Finding nearest tree");

            TreeGenerator treeSanctuary = GameObject.Find("Tree Sanctuary").GetComponent<TreeGenerator>();

            TreeScript nearestTree;

            if (!treeSanctuary.CalculateNearestTree(villagerRef, out nearestTree))
            {
                return BTStatus.FAILURE;
            }

            vBB.MoveToLocation = nearestTree.transform.position;

            return BTStatus.SUCCESS;
        }
    }

    public class VillagerWaitTillAtLocation : BTNode
    {
        private VillagerBB vBB;
        private Villager VillagerRef;

        public VillagerWaitTillAtLocation(BaseBlackboard bb, Villager villager) : base(bb)
        {
            vBB = (VillagerBB)bb;
            VillagerRef = villager;
        }

        public override BTStatus Execute()
        {
            BTStatus rv = BTStatus.RUNNING;
            if ((VillagerRef.transform.position - vBB.MoveToLocation).magnitude <= 1.0f)
            {
                VillagerRef.navMesh.isStopped = true;
                Debug.Log("Reached target");
                rv = BTStatus.SUCCESS;
            }
            return rv;
        }

    }

    public class ChopTree : BTNode
    {
        private VillagerBB vBB;
        private Villager VillagerRef;

        public ChopTree(BaseBlackboard bb, Villager villager) : base(bb)
        {
            vBB = (VillagerBB)bb;
            VillagerRef = villager;
        }

        public override BTStatus Execute()
        {
            BTStatus rv = BTStatus.RUNNING;

            vBB.CurrentNearestTree.Chop(VillagerRef);


            if (vBB.CurrentNearestTree.Health <= 0)
            {
                return BTStatus.SUCCESS;
            }

            return rv;
        }
    }

    public class VillagerStopMovement : BTNode
    {
        private Villager VillagerRef;
        public VillagerStopMovement(BaseBlackboard bb, Villager villager) : base(bb)
        {
            VillagerRef = villager;
        }

        public override BTStatus Execute()
        {

            VillagerRef.StopMovement();
            return BTStatus.SUCCESS;
        }
    }

}

