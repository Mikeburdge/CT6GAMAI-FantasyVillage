﻿using UnityEngine;

/// <summary>
/// The blackboard contains all the USEFUL data that is required for our Behaviour Tree.
/// To be inherited
/// </summary>
public class BaseBlackboard : MonoBehaviour
{

}
