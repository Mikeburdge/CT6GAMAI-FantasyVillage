﻿using UnityEngine;
using UnityEditor;

namespace Storage
{
    public class StorageContainer
    {
        private static float maxStorageCapacity;

        private static float woodInStorage;

        private static float rocksInStorage;

        private static float foodInStorage;

        public static float WoodInStorage { get => woodInStorage; set => woodInStorage = value; }
        public static float RocksInStorage { get => rocksInStorage; set => rocksInStorage = value; }
        public static float FoodInStorage { get => foodInStorage; set => foodInStorage = value; }
        public static float MaxStorageCapacity { get => maxStorageCapacity; set => maxStorageCapacity = value; }

        public static bool AddWoodToStorage(float wood)
        {
            float AfterCalculation = WoodInStorage + wood;

            if (AfterCalculation > MaxStorageCapacity)
            {
                return false;
            }
            WoodInStorage += wood;
            return true;
        }
        public static bool TakeWoodFromStorage(float wood)
        {
            float AfterCalculation = WoodInStorage - wood;

            if (AfterCalculation < 0)
            {
                return false;
            }
            WoodInStorage -= wood;
            return true;
        }
        public static bool AddRocksToStorage(float rocks)
        {
            float AfterCalculation = RocksInStorage + rocks;

            if (AfterCalculation > MaxStorageCapacity)
            {
                return false;
            }
            RocksInStorage += rocks;
            return true;
        }
        public static bool TakeRocksFromStorage(float rocks)
        {
            float AfterCalculation = RocksInStorage - rocks;

            if (AfterCalculation < 0)
            {
                return false;
            }
            RocksInStorage -= rocks;
            return true;
        }
        public static bool AddFoodToStorage(float food)
        {
            float AfterCalculation = FoodInStorage + food;

            if (AfterCalculation > MaxStorageCapacity)
            {
                return false;
            }
            FoodInStorage += food;
            return true;
        }
        public static bool TakeFoodFromStorage(float food)
        {
            float AfterCalculation = FoodInStorage - food;

            if (AfterCalculation < 0)
            {
                return false;
            }

            FoodInStorage -= food;
            return true;
        }



    }
}